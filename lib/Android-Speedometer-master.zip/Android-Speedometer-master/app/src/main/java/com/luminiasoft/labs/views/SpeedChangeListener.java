package com.luminiasoft.labs.views;

public interface SpeedChangeListener {
	
	public void onSpeedChanged(float newSpeedValue);

}
